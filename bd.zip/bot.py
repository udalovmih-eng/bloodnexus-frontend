import asyncio
import logging
from aiogram import Bot, Dispatcher, types
from aiogram.filters import Command
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton, WebAppInfo
from aiogram.enums import ParseMode
import requests

# ============================================
# НАЛАШТУВАННЯ
# ============================================
TOKEN = "8598779608:AAFHE9nDK2cPqkBQAEwWXHTQ57UssdeKZmM"
WEBAPP_URL = "https://bloodnexus-frontend-dvpnu0f57-botik.vercel.app"
API_URL = "https://bloodnexus-api.onrender.com/api"  # ЗМІНІТЬ НА ВАШ API URL

logging.basicConfig(level=logging.INFO)
bot = Bot(token=TOKEN)
dp = Dispatcher()

# ============================================
# ДОПОМІЖНА ФУНКЦІЯ
# ============================================
def register_user(telegram_id, username, first_name):
    try:
        response = requests.post(f"{API_URL}/register", json={
            "telegram_id": telegram_id,
            "username": username,
            "first_name": first_name
        })
        return response.json()
    except:
        return None

# ============================================
# КОМАНДА /start
# ============================================
@dp.message(Command("start"))
async def start_command(message: types.Message):
    register_user(
        message.from_user.id,
        message.from_user.username,
        message.from_user.first_name
    )
    
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(
            text="🚀 Відкрити BloodNexus",
            web_app=WebAppInfo(url=WEBAPP_URL)
        )],
        [
            InlineKeyboardButton(text="👤 Профіль", callback_data="profile"),
            InlineKeyboardButton(text="🛒 Магазин", callback_data="shop")
        ],
        [
            InlineKeyboardButton(text="📦 Інвентар", callback_data="inventory"),
            InlineKeyboardButton(text="💰 Баланс", callback_data="balance")
        ],
        [InlineKeyboardButton(text="📅 Щоденний бонус", callback_data="daily")]
    ])
    
    await message.answer(
        f"🔥 <b>Ласкаво просимо до BloodNexus, {message.from_user.first_name}!</b>\n\n"
        "Я бот для Telegram-чатів з безліччю функцій:\n"
        "• 🛡 Модерація (бан, мут, варни, антиспам)\n"
        "• 💰 Економіка (монети, скіни, івенти)\n"
        "• 🎮 Ігри та розваги\n\n"
        "👇 Натисніть кнопку, щоб відкрити повноцінний додаток!",
        reply_markup=keyboard,
        parse_mode=ParseMode.HTML
    )

# ============================================
# КОМАНДА /help
# ============================================
@dp.message(Command("help"))
async def help_command(message: types.Message):
    await message.answer(
        "📖 <b>Список команд:</b>\n\n"
        "/start - Головне меню\n"
        "/profile - Ваш профіль\n"
        "/shop - Магазин скінів\n"
        "/inventory - Ваш інвентар\n"
        "/balance - Ваш баланс\n"
        "/daily - Щоденний бонус\n"
        "/top - Топ гравців\n\n"
        "<b>Адмін-команди:</b>\n"
        "/ban @user - Забанити\n"
        "/mute @user - Замутити\n"
        "/warn @user - Видати варн\n"
        "/give @user [сума] - Видати монети",
        parse_mode=ParseMode.HTML
    )

# ============================================
# КОМАНДА /profile
# ============================================
@dp.message(Command("profile"))
async def profile_command(message: types.Message):
    try:
        response = requests.get(f"{API_URL}/user", params={
            "telegram_id": message.from_user.id
        })
        if response.status_code == 200:
            user = response.json()
            await message.answer(
                f"👤 <b>Ваш профіль</b>\n\n"
                f"🪙 Баланс: {user['balance']} монет\n"
                f"⭐ Рівень: {user['level']}\n"
                f"📊 Досвід: {user['experience']}\n"
                f"📅 У боті з: {user['created_at'][:10]}",
                parse_mode=ParseMode.HTML
            )
        else:
            await message.answer("❌ Не вдалося отримати профіль")
    except:
        await message.answer(
            "👤 <b>Ваш профіль</b>\n\n"
            "🪙 Баланс: 100 монет\n"
            "⭐ Рівень: 1\n"
            "📊 Досвід: 0 / 1000",
            parse_mode=ParseMode.HTML
        )

# ============================================
# КОМАНДА /balance
# ============================================
@dp.message(Command("balance"))
async def balance_command(message: types.Message):
    try:
        response = requests.get(f"{API_URL}/user", params={
            "telegram_id": message.from_user.id
        })
        if response.status_code == 200:
            user = response.json()
            await message.answer(f"🪙 <b>Ваш баланс:</b> {user['balance']} монет", parse_mode=ParseMode.HTML)
        else:
            await message.answer("🪙 <b>Ваш баланс:</b> 100 монет", parse_mode=ParseMode.HTML)
    except:
        await message.answer("🪙 <b>Ваш баланс:</b> 100 монет", parse_mode=ParseMode.HTML)

# ============================================
# КОМАНДА /daily
# ============================================
@dp.message(Command("daily"))
async def daily_command(message: types.Message):
    try:
        response = requests.post(f"{API_URL}/daily", json={
            "telegram_id": message.from_user.id
        })
        data = response.json()
        if data['success']:
            await message.answer(
                f"📅 <b>Щоденний бонус!</b>\n\n✅ {data['message']}",
                parse_mode=ParseMode.HTML
            )
        else:
            await message.answer(f"❌ {data['message']}", parse_mode=ParseMode.HTML)
    except:
        await message.answer(
            "📅 <b>Щоденний бонус!</b>\n\n✅ Ви отримали +50 монет!",
            parse_mode=ParseMode.HTML
        )

# ============================================
# КОМАНДА /top
# ============================================
@dp.message(Command("top"))
async def top_command(message: types.Message):
    await message.answer(
        "🏆 <b>Топ гравців</b>\n\n"
        "1️⃣ @andrii — 1,250 🪙\n"
        "2️⃣ @maxim — 980 🪙\n"
        "3️⃣ @olena — 750 🪙\n"
        "4️⃣ @dima — 620 🪙\n"
        "5️⃣ @katya — 510 🪙",
        parse_mode=ParseMode.HTML
    )

# ============================================
# ОБРОБКА КНОПОК
# ============================================
@dp.callback_query()
async def handle_callback(callback: types.CallbackQuery):
    data = callback.data
    
    if data == "profile":
        await callback.message.answer(
            "👤 <b>Ваш профіль</b>\n\n"
            "🪙 Баланс: 100 монет\n"
            "⭐ Рівень: 1\n"
            "📦 Скінів: 0",
            parse_mode=ParseMode.HTML
        )
    
    elif data == "shop":
        keyboard = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(
                text="🛒 Відкрити магазин",
                web_app=WebAppInfo(url=WEBAPP_URL + "/shop.html")
            )]
        ])
        await callback.message.answer(
            "🛒 <b>Магазин скінів</b>\n\n"
            "Натисніть кнопку, щоб відкрити магазин у додатку.",
            reply_markup=keyboard,
            parse_mode=ParseMode.HTML
        )
    
    elif data == "inventory":
        keyboard = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(
                text="📦 Відкрити інвентар",
                web_app=WebAppInfo(url=WEBAPP_URL + "/inventory.html")
            )]
        ])
        await callback.message.answer(
            "📦 <b>Ваш інвентар</b>\n\n"
            "Натисніть кнопку, щоб відкрити інвентар у додатку.",
            reply_markup=keyboard,
            parse_mode=ParseMode.HTML
        )
    
    elif data == "balance":
        await callback.message.answer("🪙 <b>Ваш баланс:</b> 100 монет", parse_mode=ParseMode.HTML)
    
    elif data == "daily":
        await callback.message.answer(
            "📅 <b>Щоденний бонус!</b>\n\n✅ Ви отримали +50 монет!",
            parse_mode=ParseMode.HTML
        )
    
    await callback.answer()

# ============================================
# ЗАПУСК БОТА
# ============================================
async def main():
    print("🚀 Бот BloodNexus запускається...")
    print(f"🌐 Mini App URL: {WEBAPP_URL}")
    print(f"📡 API URL: {API_URL}")
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())